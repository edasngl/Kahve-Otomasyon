﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Giris : Form
    {
        public Giris()
        {
            InitializeComponent();
        }

        private void Giris_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Text = "KAHVE SAĞLIĞINIZI TETİKLER! İÇMENİZ TAVSİYE EDİLMEZ.";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = "KAHVE SAĞLIĞINIZI TETİKLER! İÇMENİZ TAVSİYE EDİLMEZ.";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label3.Text = "KAHVE SAĞLIĞINIZI TETİKLER! İÇMENİZ TAVSİYE EDİLMEZ.";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
            form1sec.Show();
            this.Hide();
        }
    }
}
