﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Filtre : Form
    {
        public Filtre()
        {
            InitializeComponent();
        }

        private void geri_don_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
               form1sec.Show();
               this.Hide();
        }

        private void seker_Click(object sender, EventArgs e)
        {
            seker.Enabled = false;
            label3.Text = "Eklendi.";
        }

        private void Filtre_Load(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void tamamla_Click(object sender, EventArgs e)
        {
            Tamamla git = new Tamamla();
            git.Show();
            this.Hide();
        }
    }
}
