﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Mocha : Form
    {
        public Mocha()
        {
            InitializeComponent();
        }

        private void geri_don_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
                   form1sec.Show();
                   this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            label3.Text = "Eklendi.";
        }

        private void beyaz_cikolata_Click(object sender, EventArgs e)
        {
            beyaz_cikolata.Enabled = false;
            label3.Text = "Eklendi.";
        }

        private void Mocha_Load(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void tamamla_Click(object sender, EventArgs e)
        {
            Tamamla git = new Tamamla();
            git.Show();
            this.Hide();
        }
    }
}
