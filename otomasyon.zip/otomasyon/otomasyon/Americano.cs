﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Americano : Form
    {
        public Americano()
        {
            InitializeComponent();
        }

        private void geri_don_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
                      form1sec.Show();
                      this.Hide();
        }

        private void buz_Click(object sender, EventArgs e)
        {
            buz.Enabled = false;
            label3.Text = "Buz Eklendi.";
        }

        private void Americano_Load(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void tamamla_Click(object sender, EventArgs e)
        {
            Tamamla git = new Tamamla();
            git.Show();
            this.Hide();
        }
    }
}
