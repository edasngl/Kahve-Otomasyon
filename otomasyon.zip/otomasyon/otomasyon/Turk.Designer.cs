﻿namespace otomasyon
{
    partial class Turk
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.kahve = new System.Windows.Forms.Button();
            this.su = new System.Windows.Forms.Button();
            this.tek_seker = new System.Windows.Forms.Button();
            this.cift_seker = new System.Windows.Forms.Button();
            this.tamamla = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(269, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 69);
            this.label1.TabIndex = 0;
            this.label1.Text = "Türk Kahvesi";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(187, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(401, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 390);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(214, 48);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // kahve
            // 
            this.kahve.Enabled = false;
            this.kahve.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.kahve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.kahve.Location = new System.Drawing.Point(187, 166);
            this.kahve.Name = "kahve";
            this.kahve.Size = new System.Drawing.Size(142, 50);
            this.kahve.TabIndex = 3;
            this.kahve.Text = "Kahve";
            this.kahve.UseVisualStyleBackColor = true;
            // 
            // su
            // 
            this.su.Enabled = false;
            this.su.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.su.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.su.Location = new System.Drawing.Point(414, 166);
            this.su.Name = "su";
            this.su.Size = new System.Drawing.Size(142, 50);
            this.su.TabIndex = 4;
            this.su.Text = "Su";
            this.su.UseVisualStyleBackColor = true;
            // 
            // tek_seker
            // 
            this.tek_seker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tek_seker.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tek_seker.ForeColor = System.Drawing.Color.White;
            this.tek_seker.Location = new System.Drawing.Point(187, 275);
            this.tek_seker.Name = "tek_seker";
            this.tek_seker.Size = new System.Drawing.Size(169, 50);
            this.tek_seker.TabIndex = 5;
            this.tek_seker.Text = "Tek Şeker";
            this.tek_seker.UseVisualStyleBackColor = false;
            this.tek_seker.Click += new System.EventHandler(this.tek_seker_Click);
            // 
            // cift_seker
            // 
            this.cift_seker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cift_seker.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cift_seker.ForeColor = System.Drawing.Color.White;
            this.cift_seker.Location = new System.Drawing.Point(387, 275);
            this.cift_seker.Name = "cift_seker";
            this.cift_seker.Size = new System.Drawing.Size(169, 50);
            this.cift_seker.TabIndex = 6;
            this.cift_seker.Text = "Çift Şeker";
            this.cift_seker.UseVisualStyleBackColor = false;
            this.cift_seker.Click += new System.EventHandler(this.cift_seker_Click);
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(642, 395);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(146, 43);
            this.tamamla.TabIndex = 7;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(350, 132);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            // 
            // Turk
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.cift_seker);
            this.Controls.Add(this.tek_seker);
            this.Controls.Add(this.su);
            this.Controls.Add(this.kahve);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Turk";
            this.Text = "Turk";
            this.Load += new System.EventHandler(this.Turk_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button kahve;
        private Button su;
        private Button tek_seker;
        private Button cift_seker;
        private Button tamamla;
        private Label label3;
    }
}