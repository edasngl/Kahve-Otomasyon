﻿namespace otomasyon
{
    partial class Maccihato
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.kahve = new System.Windows.Forms.Button();
            this.su = new System.Windows.Forms.Button();
            this.sut = new System.Windows.Forms.Button();
            this.seker = new System.Windows.Forms.Button();
            this.karamel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tamamla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(233, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(316, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Coffee Maccihato";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(191, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(401, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 383);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(217, 55);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // kahve
            // 
            this.kahve.Enabled = false;
            this.kahve.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.kahve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.kahve.Location = new System.Drawing.Point(112, 159);
            this.kahve.Name = "kahve";
            this.kahve.Size = new System.Drawing.Size(229, 53);
            this.kahve.TabIndex = 3;
            this.kahve.Text = "Granül Kahve";
            this.kahve.UseVisualStyleBackColor = true;
            // 
            // su
            // 
            this.su.Enabled = false;
            this.su.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.su.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.su.Location = new System.Drawing.Point(389, 159);
            this.su.Name = "su";
            this.su.Size = new System.Drawing.Size(94, 53);
            this.su.TabIndex = 4;
            this.su.Text = "Su";
            this.su.UseVisualStyleBackColor = true;
            // 
            // sut
            // 
            this.sut.Enabled = false;
            this.sut.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.sut.Location = new System.Drawing.Point(532, 159);
            this.sut.Name = "sut";
            this.sut.Size = new System.Drawing.Size(94, 53);
            this.sut.TabIndex = 5;
            this.sut.Text = "Süt";
            this.sut.UseVisualStyleBackColor = true;
            // 
            // seker
            // 
            this.seker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.seker.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seker.ForeColor = System.Drawing.Color.White;
            this.seker.Location = new System.Drawing.Point(196, 244);
            this.seker.Name = "seker";
            this.seker.Size = new System.Drawing.Size(145, 53);
            this.seker.TabIndex = 6;
            this.seker.Text = "Şeker";
            this.seker.UseVisualStyleBackColor = false;
            this.seker.Click += new System.EventHandler(this.seker_Click);
            // 
            // karamel
            // 
            this.karamel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.karamel.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.karamel.ForeColor = System.Drawing.Color.White;
            this.karamel.Location = new System.Drawing.Point(425, 244);
            this.karamel.Name = "karamel";
            this.karamel.Size = new System.Drawing.Size(145, 53);
            this.karamel.TabIndex = 7;
            this.karamel.Text = "Karamel";
            this.karamel.UseVisualStyleBackColor = false;
            this.karamel.Click += new System.EventHandler(this.karamel_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(365, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(647, 398);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(141, 40);
            this.tamamla.TabIndex = 9;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // Maccihato
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.karamel);
            this.Controls.Add(this.seker);
            this.Controls.Add(this.sut);
            this.Controls.Add(this.su);
            this.Controls.Add(this.kahve);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Maccihato";
            this.Text = "Maccihato";
            this.Load += new System.EventHandler(this.Maccihato_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button kahve;
        private Button su;
        private Button sut;
        private Button seker;
        private Button karamel;
        private Label label3;
        private Button tamamla;
    }
}