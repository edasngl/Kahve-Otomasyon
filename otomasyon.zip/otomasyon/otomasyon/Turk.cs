﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Turk : Form
    {
        public Turk()
        {
            InitializeComponent();
        }

        private void geri_don_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
                   form1sec.Show();
                    this.Hide();
        }

        private void tek_seker_Click(object sender, EventArgs e)
        {
            tek_seker.Enabled = false;
            label3.Text = "Eklendi.";
        }

        private void cift_seker_Click(object sender, EventArgs e)
        {
            cift_seker.Enabled = false;
            label3.Text = "Eklendi.";
        }

        private void Turk_Load(object sender, EventArgs e)
        {
            label3.Text = "";
        }

        private void tamamla_Click(object sender, EventArgs e)
        {
            Tamamla git = new Tamamla();
            git.Show();
            this.Hide();
        }
    }
}
