namespace otomasyon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void espresso_Click(object sender, EventArgs e)
        {
            Espresso espresso = new Espresso();
            espresso.Show();
                       this.Hide();
        }

        private void cappucino_Click(object sender, EventArgs e)
        {
            Cappucino cappucino = new Cappucino();
            cappucino.Show();
            this.Hide();
        }

        private void americano_Click(object sender, EventArgs e)
        {
            Americano americano = new Americano();
            americano.Show();
            this.Hide();
        }

        private void latte_Click(object sender, EventArgs e)
        {
            Latte latte = new Latte();
            latte.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Turk turk = new Turk();
            turk.Show();
            this.Hide();
        }

        private void maccihato_Click(object sender, EventArgs e)
        {
            Maccihato maccihato = new Maccihato();
            maccihato.Show();
            this.Hide();
        }

        private void mocha_Click(object sender, EventArgs e)
        {
            Mocha mocha = new Mocha();
            mocha.Show();
            this.Hide();
        }

        private void filtre_Click(object sender, EventArgs e)
        {
            Filtre filtre = new Filtre();
            filtre.Show();
            this.Hide();
        }
    }
}