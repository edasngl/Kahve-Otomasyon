﻿namespace otomasyon
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.espresso = new System.Windows.Forms.Button();
            this.cappucino = new System.Windows.Forms.Button();
            this.americano = new System.Windows.Forms.Button();
            this.latte = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.maccihato = new System.Windows.Forms.Button();
            this.mocha = new System.Windows.Forms.Button();
            this.filtre = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // espresso
            // 
            this.espresso.Font = new System.Drawing.Font("Showcard Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.espresso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.espresso.Location = new System.Drawing.Point(12, 146);
            this.espresso.Name = "espresso";
            this.espresso.Size = new System.Drawing.Size(188, 54);
            this.espresso.TabIndex = 0;
            this.espresso.Text = "Espresso";
            this.espresso.UseVisualStyleBackColor = true;
            this.espresso.Click += new System.EventHandler(this.espresso_Click);
            // 
            // cappucino
            // 
            this.cappucino.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cappucino.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.cappucino.Location = new System.Drawing.Point(206, 146);
            this.cappucino.Name = "cappucino";
            this.cappucino.Size = new System.Drawing.Size(211, 53);
            this.cappucino.TabIndex = 1;
            this.cappucino.Text = "Cappuccino";
            this.cappucino.UseVisualStyleBackColor = true;
            this.cappucino.Click += new System.EventHandler(this.cappucino_Click);
            // 
            // americano
            // 
            this.americano.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.americano.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.americano.Location = new System.Drawing.Point(452, 331);
            this.americano.Name = "americano";
            this.americano.Size = new System.Drawing.Size(308, 54);
            this.americano.TabIndex = 2;
            this.americano.Text = "Americano";
            this.americano.UseVisualStyleBackColor = true;
            this.americano.Click += new System.EventHandler(this.americano_Click);
            // 
            // latte
            // 
            this.latte.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.latte.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.latte.Location = new System.Drawing.Point(432, 146);
            this.latte.Name = "latte";
            this.latte.Size = new System.Drawing.Size(146, 54);
            this.latte.TabIndex = 3;
            this.latte.Text = "Latte";
            this.latte.UseVisualStyleBackColor = true;
            this.latte.Click += new System.EventHandler(this.latte_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(85, 246);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(253, 53);
            this.button1.TabIndex = 4;
            this.button1.Text = "Türk Kahvesi";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // maccihato
            // 
            this.maccihato.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.maccihato.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.maccihato.Location = new System.Drawing.Point(452, 245);
            this.maccihato.Name = "maccihato";
            this.maccihato.Size = new System.Drawing.Size(308, 55);
            this.maccihato.TabIndex = 5;
            this.maccihato.Text = "Coffee Maccihato";
            this.maccihato.UseVisualStyleBackColor = true;
            this.maccihato.Click += new System.EventHandler(this.maccihato_Click);
            // 
            // mocha
            // 
            this.mocha.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.mocha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.mocha.Location = new System.Drawing.Point(594, 146);
            this.mocha.Name = "mocha";
            this.mocha.Size = new System.Drawing.Size(166, 54);
            this.mocha.TabIndex = 6;
            this.mocha.Text = "Mocha";
            this.mocha.UseVisualStyleBackColor = true;
            this.mocha.Click += new System.EventHandler(this.mocha_Click);
            // 
            // filtre
            // 
            this.filtre.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.filtre.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.filtre.Location = new System.Drawing.Point(85, 326);
            this.filtre.Name = "filtre";
            this.filtre.Size = new System.Drawing.Size(253, 64);
            this.filtre.TabIndex = 7;
            this.filtre.Text = "Filtre Kahve";
            this.filtre.UseVisualStyleBackColor = true;
            this.filtre.Click += new System.EventHandler(this.filtre_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("SimSun", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(286, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 36);
            this.label1.TabIndex = 8;
            this.label1.Text = "Hoşgeldiniz";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(239, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(287, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Lütfen içmek istediğiniz kahveye tıklayınız.";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(95, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(105, 103);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Enabled = false;
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(555, 25);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(105, 103);
            this.pictureBox2.TabIndex = 11;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filtre);
            this.Controls.Add(this.mocha);
            this.Controls.Add(this.maccihato);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.latte);
            this.Controls.Add(this.americano);
            this.Controls.Add(this.cappucino);
            this.Controls.Add(this.espresso);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button espresso;
        private Button cappucino;
        private Button americano;
        private Button latte;
        private Button button1;
        private Button maccihato;
        private Button mocha;
        private Button filtre;
        private Label label1;
        private Label label2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}