﻿namespace otomasyon
{
    partial class Americano
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.espresso = new System.Windows.Forms.Button();
            this.su = new System.Windows.Forms.Button();
            this.buz = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tamamla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(282, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Americano ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(169, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(401, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 392);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(214, 46);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // espresso
            // 
            this.espresso.Enabled = false;
            this.espresso.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.espresso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.espresso.Location = new System.Drawing.Point(169, 185);
            this.espresso.Name = "espresso";
            this.espresso.Size = new System.Drawing.Size(165, 52);
            this.espresso.TabIndex = 3;
            this.espresso.Text = "Espresso";
            this.espresso.UseVisualStyleBackColor = true;
            // 
            // su
            // 
            this.su.Enabled = false;
            this.su.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.su.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.su.Location = new System.Drawing.Point(421, 185);
            this.su.Name = "su";
            this.su.Size = new System.Drawing.Size(149, 52);
            this.su.TabIndex = 4;
            this.su.Text = "Su";
            this.su.UseVisualStyleBackColor = true;
            // 
            // buz
            // 
            this.buz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buz.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buz.ForeColor = System.Drawing.SystemColors.Window;
            this.buz.Location = new System.Drawing.Point(318, 325);
            this.buz.Name = "buz";
            this.buz.Size = new System.Drawing.Size(119, 54);
            this.buz.TabIndex = 5;
            this.buz.Text = "Buz";
            this.buz.UseVisualStyleBackColor = false;
            this.buz.Click += new System.EventHandler(this.buz_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(351, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "label3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(639, 392);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(149, 45);
            this.tamamla.TabIndex = 7;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // Americano
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.buz);
            this.Controls.Add(this.su);
            this.Controls.Add(this.espresso);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Americano";
            this.Text = "Americano";
            this.Load += new System.EventHandler(this.Americano_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button espresso;
        private Button su;
        private Button buz;
        private Label label3;
        private Button tamamla;
    }
}