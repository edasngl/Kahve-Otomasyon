﻿namespace otomasyon
{
    partial class Mocha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.kahve = new System.Windows.Forms.Button();
            this.su = new System.Windows.Forms.Button();
            this.sut = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.beyaz_cikolata = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tamamla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(304, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 59);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mocha";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(190, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(401, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 389);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(226, 49);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // kahve
            // 
            this.kahve.Enabled = false;
            this.kahve.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.kahve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.kahve.Location = new System.Drawing.Point(159, 154);
            this.kahve.Name = "kahve";
            this.kahve.Size = new System.Drawing.Size(136, 54);
            this.kahve.TabIndex = 3;
            this.kahve.Text = "Kahve";
            this.kahve.UseVisualStyleBackColor = true;
            // 
            // su
            // 
            this.su.Enabled = false;
            this.su.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.su.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.su.Location = new System.Drawing.Point(337, 154);
            this.su.Name = "su";
            this.su.Size = new System.Drawing.Size(136, 54);
            this.su.TabIndex = 4;
            this.su.Text = "Su";
            this.su.UseVisualStyleBackColor = true;
            // 
            // sut
            // 
            this.sut.Enabled = false;
            this.sut.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.sut.Location = new System.Drawing.Point(516, 154);
            this.sut.Name = "sut";
            this.sut.Size = new System.Drawing.Size(136, 54);
            this.sut.TabIndex = 5;
            this.sut.Text = "Süt";
            this.sut.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.button1.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(159, 269);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 54);
            this.button1.TabIndex = 6;
            this.button1.Text = "Şeker";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // beyaz_cikolata
            // 
            this.beyaz_cikolata.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.beyaz_cikolata.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.beyaz_cikolata.ForeColor = System.Drawing.Color.White;
            this.beyaz_cikolata.Location = new System.Drawing.Point(398, 269);
            this.beyaz_cikolata.Name = "beyaz_cikolata";
            this.beyaz_cikolata.Size = new System.Drawing.Size(254, 54);
            this.beyaz_cikolata.TabIndex = 7;
            this.beyaz_cikolata.Text = "Beyaz Çikolata";
            this.beyaz_cikolata.UseVisualStyleBackColor = false;
            this.beyaz_cikolata.Click += new System.EventHandler(this.beyaz_cikolata_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(359, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(640, 396);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(148, 43);
            this.tamamla.TabIndex = 9;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // Mocha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.beyaz_cikolata);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.sut);
            this.Controls.Add(this.su);
            this.Controls.Add(this.kahve);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Mocha";
            this.Text = "Mocha";
            this.Load += new System.EventHandler(this.Mocha_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button kahve;
        private Button su;
        private Button sut;
        private Button button1;
        private Button beyaz_cikolata;
        private Label label3;
        private Button tamamla;
    }
}