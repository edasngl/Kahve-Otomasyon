﻿namespace otomasyon
{
    partial class Filtre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.filtre_kahve = new System.Windows.Forms.Button();
            this.su = new System.Windows.Forms.Button();
            this.seker = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tamamla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(260, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(233, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Filtre Kahve";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(189, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(398, 40);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız\r\n.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 391);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(215, 47);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // filtre_kahve
            // 
            this.filtre_kahve.Enabled = false;
            this.filtre_kahve.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.filtre_kahve.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.filtre_kahve.Location = new System.Drawing.Point(189, 152);
            this.filtre_kahve.Name = "filtre_kahve";
            this.filtre_kahve.Size = new System.Drawing.Size(205, 50);
            this.filtre_kahve.TabIndex = 3;
            this.filtre_kahve.Text = "Filtre Kahve";
            this.filtre_kahve.UseVisualStyleBackColor = true;
            // 
            // su
            // 
            this.su.Enabled = false;
            this.su.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.su.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.su.Location = new System.Drawing.Point(428, 152);
            this.su.Name = "su";
            this.su.Size = new System.Drawing.Size(90, 50);
            this.su.TabIndex = 4;
            this.su.Text = "Su";
            this.su.UseVisualStyleBackColor = true;
            // 
            // seker
            // 
            this.seker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.seker.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seker.ForeColor = System.Drawing.Color.White;
            this.seker.Location = new System.Drawing.Point(338, 243);
            this.seker.Name = "seker";
            this.seker.Size = new System.Drawing.Size(121, 50);
            this.seker.TabIndex = 5;
            this.seker.Text = "Şeker";
            this.seker.UseVisualStyleBackColor = false;
            this.seker.Click += new System.EventHandler(this.seker_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(371, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "label3";
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(645, 396);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(143, 42);
            this.tamamla.TabIndex = 7;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // Filtre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.seker);
            this.Controls.Add(this.su);
            this.Controls.Add(this.filtre_kahve);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Filtre";
            this.Text = "Filtre";
            this.Load += new System.EventHandler(this.Filtre_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button filtre_kahve;
        private Button su;
        private Button seker;
        private Label label3;
        private Button tamamla;
    }
}