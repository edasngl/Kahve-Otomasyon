﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace otomasyon
{
    public partial class Latte : Form
    {
        public Latte()
        {
            InitializeComponent();
        }

        private void geri_don_Click(object sender, EventArgs e)
        {
            Form1 form1sec = new Form1();
               form1sec.Show();
               this.Hide();
        }

        private void kopuk_Click(object sender, EventArgs e)
        {
            kopuk.Enabled = false;
            label7.Text = "Eklendi.";
        }

        private void Latte_Load(object sender, EventArgs e)
        {
            label7.Text = "";
        }

        private void seker_Click(object sender, EventArgs e)
        {
            seker.Enabled = false;
            label7.Text = "Eklendi.";
        }

        private void karamel_Click(object sender, EventArgs e)
        {
            karamel.Enabled = false;
            label7.Text = "Eklendi.";
        }

        private void sutlu_cikolata_Click(object sender, EventArgs e)
        {
            sutlu_cikolata.Enabled = false;
            label7.Text = "Eklendi.";
        }

        private void beyaz_cikolata_Click(object sender, EventArgs e)
        {
            beyaz_cikolata.Enabled = false;
            label7.Text = "Eklendi.";

        }

        private void tamamla_Click(object sender, EventArgs e)
        {
            Tamamla git = new Tamamla();
            git.Show();
            this.Hide();
        }
    }
}
