﻿namespace otomasyon
{
    partial class Cappucino
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.geri_don = new System.Windows.Forms.Button();
            this.espresso = new System.Windows.Forms.Button();
            this.kopuk = new System.Windows.Forms.Button();
            this.sut = new System.Windows.Forms.Button();
            this.seker = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buz = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tamamla = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(279, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cappuccino";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(168, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(401, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lütfen eklemek/çıkarmak istediğiniz malzemelere tıklayınız.";
            // 
            // geri_don
            // 
            this.geri_don.Font = new System.Drawing.Font("Sitka Small", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.geri_don.Location = new System.Drawing.Point(12, 381);
            this.geri_don.Name = "geri_don";
            this.geri_don.Size = new System.Drawing.Size(210, 57);
            this.geri_don.TabIndex = 2;
            this.geri_don.Text = "Anasayfaya Dön";
            this.geri_don.UseVisualStyleBackColor = true;
            this.geri_don.Click += new System.EventHandler(this.geri_don_Click);
            // 
            // espresso
            // 
            this.espresso.Enabled = false;
            this.espresso.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.espresso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.espresso.Location = new System.Drawing.Point(129, 153);
            this.espresso.Name = "espresso";
            this.espresso.Size = new System.Drawing.Size(176, 60);
            this.espresso.TabIndex = 3;
            this.espresso.Text = "Espresso";
            this.espresso.UseVisualStyleBackColor = true;
            // 
            // kopuk
            // 
            this.kopuk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.kopuk.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.kopuk.ForeColor = System.Drawing.Color.White;
            this.kopuk.Location = new System.Drawing.Point(138, 290);
            this.kopuk.Name = "kopuk";
            this.kopuk.Size = new System.Drawing.Size(155, 60);
            this.kopuk.TabIndex = 5;
            this.kopuk.Text = "Köpük";
            this.kopuk.UseVisualStyleBackColor = false;
            this.kopuk.Click += new System.EventHandler(this.kopuk_Click);
            // 
            // sut
            // 
            this.sut.Enabled = false;
            this.sut.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.sut.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.sut.Location = new System.Drawing.Point(478, 153);
            this.sut.Name = "sut";
            this.sut.Size = new System.Drawing.Size(176, 60);
            this.sut.TabIndex = 6;
            this.sut.Text = "Süt";
            this.sut.UseVisualStyleBackColor = true;
            // 
            // seker
            // 
            this.seker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.seker.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seker.ForeColor = System.Drawing.Color.White;
            this.seker.Location = new System.Drawing.Point(499, 290);
            this.seker.Name = "seker";
            this.seker.Size = new System.Drawing.Size(155, 60);
            this.seker.TabIndex = 7;
            this.seker.Text = "Şeker";
            this.seker.UseVisualStyleBackColor = false;
            this.seker.Click += new System.EventHandler(this.seker_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(360, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "label3";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(360, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "label4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // buz
            // 
            this.buz.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.buz.Font = new System.Drawing.Font("Sitka Small", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buz.ForeColor = System.Drawing.Color.White;
            this.buz.Location = new System.Drawing.Point(316, 290);
            this.buz.Name = "buz";
            this.buz.Size = new System.Drawing.Size(155, 60);
            this.buz.TabIndex = 10;
            this.buz.Text = "Buz";
            this.buz.UseVisualStyleBackColor = false;
            this.buz.Click += new System.EventHandler(this.buz_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(360, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 20);
            this.label5.TabIndex = 11;
            this.label5.Text = "label5";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tamamla
            // 
            this.tamamla.Location = new System.Drawing.Point(631, 381);
            this.tamamla.Name = "tamamla";
            this.tamamla.Size = new System.Drawing.Size(157, 47);
            this.tamamla.TabIndex = 12;
            this.tamamla.Text = "Kahveyi Tamamla";
            this.tamamla.UseVisualStyleBackColor = true;
            this.tamamla.Click += new System.EventHandler(this.tamamla_Click);
            // 
            // Cappucino
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tamamla);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.buz);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.seker);
            this.Controls.Add(this.sut);
            this.Controls.Add(this.kopuk);
            this.Controls.Add(this.espresso);
            this.Controls.Add(this.geri_don);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Cappucino";
            this.Text = "Cappucino";
            this.Load += new System.EventHandler(this.Cappucino_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private Label label2;
        private Button geri_don;
        private Button espresso;
        private Button kopuk;
        private Button sut;
        private Button seker;
        private Label label3;
        private Label label4;
        private Button buz;
        private Label label5;
        private Button tamamla;
    }
}